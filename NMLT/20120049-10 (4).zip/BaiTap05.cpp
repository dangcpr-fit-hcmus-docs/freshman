// BaiTap02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;
int demSoAm(int n) {
    int dem=0;
    while (n != 0)
        {
            if (n < 0)
            {
                dem = dem + 1;
            }
            cin >> n;
        }
    return dem;
}
int main() {
    int n;
    cin >> n;
    cout << "So luong so am ban nhap la " << demSoAm(n);
    return 0;
}


