// BaiTap01.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}

bool ktSoHoanChinh(unsigned int n) {
    int S = 0, P = 1;
    bool kq;
    for (int i = 1; i < n; i++)
        {
            if (n % i == 0)
                {
                    S = S + i;
                    P = P * i;
                }
        }
    if (S == n && P == n)
        {
            kq = true;
        }
    else
        {
            kq = false;
        }
    return kq;
}
int main() {
    unsigned int n;
    cout << "Nhap so nguyen duong n = ";
	cin >> n;
    nhapSoDuong(n);
    if (ktSoHoanChinh(n) == true)
    {
        cout << n << " la so hoan chinh.";
    }
    else
    {
        cout << n << " khong phai la so hoan chinh.";
    }
    return 0;
}
