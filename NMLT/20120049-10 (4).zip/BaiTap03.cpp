// BaiTap01.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}

bool ktSoHoanHao(unsigned int n) {
    int S = 0;
    bool kq;
    for (int i = 1; i <= n; i++)
    {
        if (n % i == 0)
        {
            S = S + i;
        }
    }
    if (S == n*2)
    {
        kq = true;
    }
    else
    {
        kq = false;
    }
    return kq;
}
int main() {
    unsigned int n;
    cin >> n;
    nhapSoDuong(n);
    if (ktSoHoanHao(n) == true)
    {
        cout << n << " la so hoan hao.";
    }
    else
    {
        cout << n << " khong phai la so hoan hao.";
    }
    return 0;
}
