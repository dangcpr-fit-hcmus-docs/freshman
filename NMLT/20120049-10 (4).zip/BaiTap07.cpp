// BaiTap07.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}
int timBCNN(unsigned int a, unsigned int b) {
    int i = b;
    while (i % nhapSoDuong(a) != 0 || i % nhapSoDuong(b) != 0)
    {
        i = i + 1;
    }
    return i;
}
int main() {
    unsigned int a, b;
    cout << "Nhap 2 so duong a,b: ";
    cin >> a >> b;
    cout << "BCNN = " << timBCNN(a, b);
    return 0;
}
