// BaiTap02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}
bool ktSoDoiXung(unsigned int n) {
    int k1 = n, k2 = n, t = 0, tong = 0;
    bool kq;
    while (k1 != 0)
        {
            t = t + 1;
            k1 = k1 / 10;
        }
    for (int i = t-1; i >= 0; i--)
        {
            int s = k2 % 10;
            tong = tong + s*pow(10,i);
            k2 = k2 / 10;
        }
    if (tong == n)
        {
            kq = true;
        }
    else
        {
            kq = false;
        }
    return kq;
}
int main() {
    unsigned int n;
    cin >> n;
    nhapSoDuong(n);
    if (ktSoDoiXung(n) == true)
        {
            cout << n << " la so doi xung.";
        }
    else
        { 
            cout << n << " la khong phai so doi xung.";
        }
    return 0;
}



