// BaiTap02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}
int timChuSoLonNhat(unsigned int n) {
    int max, s;
    max = n % 10;
    while (n != 0)
    {
        s = n % 10;
        if (s > max)
            {
                max = s;
            }
        n = n / 10;
    }
    return max;
}
int main() {
    unsigned int n;
    cin >> n;
    nhapSoDuong(n);
    cout << "Chu so lon nhat la: " << timChuSoLonNhat(n);
    return 0;
}
