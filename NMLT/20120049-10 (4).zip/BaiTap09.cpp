// BaiTap09.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;
int chuyenNhiPhan(int n)
{
    int i = 0;
    int tong = 0;
    while (n > 0)
        {
            int s = n % 2;
            tong = tong + s * pow(10, i);
            n = n / 2;
            i++;
        }
    return tong;
}
int main() {
    int n;
    cout << "Nhap so nguyen n = ";
    cin >> n;
    cout << "So nhi phan tuong ung la " << chuyenNhiPhan(n);
}
