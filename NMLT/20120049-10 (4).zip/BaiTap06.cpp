// BaiTap06.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int nhapSoDuong(unsigned int n) {
    return n;
}
int timUCLN(unsigned int a, unsigned int b) {
    int i;
    for (i = b; i >= 1; i--)
        {
            if (nhapSoDuong(a) % i == 0 && nhapSoDuong(b) % i == 0)
            {
                break;
            }
        }
    return i;
}
int main() {
    unsigned int a, b;
    cout << "Nhap 2 so duong a,b: ";
    cin >> a >> b;
    cout << "UCLN = " << timUCLN(a, b);
    return 0;
}
