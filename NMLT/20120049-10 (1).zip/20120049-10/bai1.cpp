//1. Viet chuong trinh in ra cac dong chu sau day:
#include <iostream>

int main()
{
    std::cout << "1. In C, lowercase letters are significant.\n"; 
	std::cout << "2. main is where program execution begins.\n";
	std::cout << "3. Opening and closing braces enclose program statements in a routine.\n";
	std::cout << "4. All program statements must be terminated by a semicolon.";
}


