//Nhap chieu d�i canh h�nh vu�ng. T�nh v� in ra chu vi, dien t�ch h�nh vu�ng d�.
#include <iostream>
using namespace std;

int main()
{
	int x;
	cout << "Nhap chieu dai canh hinh vuong: ";
	cin >> x;
	cout << "Chu vi: " << 4*x << "\n";
	cout << "Dien tich: " << x*x << "\n";
	return 0;
}
