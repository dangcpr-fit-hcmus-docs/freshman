// BaiTap08.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int main()
{
	int x, y, i;
	cout << "Nhap 2 so nguyen duong x va y: ";
	cin >> x >> y;
	for (i = y; i >= 1; i--)
	{
		if (x % i == 0 & y % i == 0)
		{
			cout << "UCLN = " << i << endl;
			break;
		}
	};
	i = x;
	while (i % x != 0 || i % y != 0)
	{
		i++;
	}
	cout << "BCNN = " << i;
}


