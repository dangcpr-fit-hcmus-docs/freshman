#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int i,j;
	for (i=2;i<=9;i++)
		{
			cout << "Bang nhan " << i << ":\n";
			for (j=1;j<=9;j++)
				{
					cout << i << " x " << j << " = " << i*j << endl;
				};
		}
	return 0;
}
