// BaiTap02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int i, n;
	float tong;
	cout << "Nhap n = ";
	cin >> n;
	tong = 0;
	for (i = 1; i <= n; i++)
	{
		tong = tong + 1.0 / i;
	};
	cout << "Tong = " << tong;
}

