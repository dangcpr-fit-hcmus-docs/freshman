// BaiTap01.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int i, n, tong;
	cout << "Nhap n = ";
	cin >> n;
	tong = 0;
	for (i = 1; i <= n; i++)
	{
		tong = tong + i * i * i;
	};
	cout << "Tong cua lap phuong " << n << " so hang dau tien la " << tong;
}

