// BaiTap04.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int i, j, n, tong, tich;
	cout << "Nhap n = ";
	cin >> n;
	tong = 0;
	for (i = 1; i <= n; i++)
	{
		tich = 1;
		for (j = 1; j <= i; j++)
		{
			tich = tich * j;
		}
		tong = tong + tich;
	}
	cout << "Tong = " << tong;
}

