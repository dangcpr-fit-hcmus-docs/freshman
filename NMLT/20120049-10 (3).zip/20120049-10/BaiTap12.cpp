#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	char chu;
	for (chu='Z';chu>='A';chu--)
		{
			cout << chu << " ";
		}
	return 0;
}
