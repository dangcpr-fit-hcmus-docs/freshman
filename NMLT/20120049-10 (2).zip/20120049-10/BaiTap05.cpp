#include <iostream>
using namespace std;
int main()
{
	int a, b, c, d, x;
	cout << "Nhap 4 so a,b,c,d: ";
	cin >> a >> b >> c >> d;
	if (a > b)
		{
			x = a;
			a = b;
			b = x;
		}
	if (a > c)
		{
			x = a;
			a = c;
			c = x;
		}
	if (a > d)
		{
			x = a;
			a = d;
			d = x;
		}
	if (b > c)
		{
			x = b;
			b = c;
			c = x;
		}
	if (b > d)
		{
			x = b;
			b = d;
			d = x;
		}
	if (c > d)
		{
			x = c;
			c = d;
			d = x;
		}
	cout << "Day so theo thu tu tang dan la: " << a << "," << b << "," << c << "," << d;
}
