#include <iostream>
using namespace std;
int main()
{
	char a;
	cout << "Nhap chu cai: ";
	cin >> a;
	if ((a >= 'A') && (a <= 'Z'))
		{
			a = a + 32;
			cout << "Chu thuong cua ki tu ban nhap la: " << a;
		}
	else
		if ((a >= 'a') && (a <= 'z'))
			{
				a = a - 32;
				cout << "Chu in hoa cua ki tu ban nhap la: " << a;
			}
}

