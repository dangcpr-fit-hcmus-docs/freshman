#include <iostream>
using namespace std;
int main()
{
	float a, b;
	cout << "Nhap he so a va b cho phuong trinh ax + b = 0: ";
	cin >> a;
	cin >> b;
	if (a==0)
		if (b == 0)
		{
			cout << "Phuong trinh co vo so nghiem";
		}
		else
		{
			cout << "Phuong trinh vo nghiem";
		}
	else
	{
		cout << "Nghiem cua phuong trinh la " << -b / a;
	}
}
