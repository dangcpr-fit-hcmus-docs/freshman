// BaiTap09.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int main()
{
    int a, b;
    cout << "Nhap thang: "; 
    cin >> a;
    cout << "Nhap nam: ";
    cin >> b;
    switch (a)
        {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            	{
                	cout << "Thang " << a << "/" << b << " co 31 ngay";
            	}; break;
            case 4:
            case 6:
            case 9:
            case 11:
            	{
                	cout << "Thang " << a << "/" << b << " co 30 ngay";
            	}; break;
            case 2:
            	{
                	if ((b % 4 == 0 && b % 100 != 0) || (b % 100 == 0 && b % 400 == 0))
                		{
                    			cout << "Thang " << a << "/" << b << " co 29 ngay";
               			}	
                	else
                		{
                    		cout << "Thang " << a << "/" << b << " co 28 ngay";
                		};
            	};break;
            default:
            	{
            		cout << "Thang ban nhap khong phai la 1 thang trong nam";
            	};
       	};
}
