#include <iostream>
using namespace std;
int main()
{
	int a, b, c, d, min;
	cout << "Nhap 4 so a,b,c,d: ";
	cin >> a >> b >> c >> d;
	min = a;
	if (b < min)
		{
			min = b;
		}
	if (c < min)
		{
			min = c;
		}
	if (d < min)
		{
			min = d;
		}
	cout << "So nho nhat la: " << min;
}
