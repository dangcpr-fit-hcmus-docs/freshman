// Bai4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	float a, b, c, d;
	cout << "Nhap he so a,b,c cua phuong trinh ax^2 + bx + c = 0: ";
	cin >> a;
	cin >> b;
	cin >> c;
	if (a==0)
		{
			cout << "Day khong phai phuong trinh bac 2";
		}
	else
		{
			d = b * b - 4 * a * c;
			if (d < 0)
				{
					cout << "Phuong trinh vo nghiem";
				}
			else
				if (d == 0)
					{
						cout << "Phuong trinh co nghiem kep la " << -b / (2 * a);
					}
				else
					{
						cout << "Phuong trinh co 2 nghiem phan biet la " << (-b + sqrt(d)) / (2 * a) << " va " << (-b - sqrt(d)) / (2 * a);
					}
		}
		

}


