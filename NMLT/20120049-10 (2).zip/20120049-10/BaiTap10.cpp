// BaiTap09.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int main()
{
    int x,a, b;
    cout << "Nhap ngay: ";
    cin >> x;
    cout << "Nhap thang: "; 
    cin >> a;
    cout << "Nhap nam: ";
    cin >> b;
	if (a<1||a>12)
		{
			cout << "Thang ban nhap khong hop le.";
		}
	else
		{
			if (x==1)
				{
					if (a==1)
						{
							cout << "Ngay truoc do la 31/12/" << b-1;
						}
					else
						{
							if (a==2 || a==4 || a==6 || a==8 || a==9 || a==11)
								{
									cout << "Ngay truoc do la 31/" << a-1 << "/" <<b;
								}
							if (a==5||a==7||a==10||a==12)
								{
									cout << "Ngay truoc do la 30/" << a-1 << "/" <<b;
								}
							if (a==3)
								{
									if ((b % 4 == 0 && b % 100 != 0) || (b % 100 == 0 && b % 400 == 0))
                						{
                    						cout << "Ngay truoc do la 29/" << a-1 << "/" <<b;
               							}	
                					else	
                						{
                    						cout << "Ngay truoc do la 28/" << a-1 << "/" <<b;
                						};
            					};		
						};
				}
			else
				{
					cout << "Ngay truoc do la " <<x-1<<"/"<< a << "/" <<b;
				};
		};
}
