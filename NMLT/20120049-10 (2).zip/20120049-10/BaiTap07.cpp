#include <iostream>
using namespace std;
int main()
{
	int a, x;
	cout << "Nhap so km di duoc: ";
	cin >> a;
	if (a <= 1)
		{
			x = a * 15000;
		}
	else
		if ((a >= 2) && (a <= 5))
		{
			x = 15000 + (a - 1) * 13500;
		}
		else
			if ((a >= 6) && (a <= 120))
			{
				x = 15000 + 4 * 13500 + (a - 5) * 12000;
			}
			else
			{
				x = (15000 + 4 * 13500 + (a - 5) * 12000) * 0.9;
			}
	cout << "Tong so tien di taxi la: " << x << " dong";	
}
