# Chicken Invaders Game 

Developer: Peter Shodeinde

Information: It uses the Starling framework. The user will use the mouse interaction for controlling the game. 
