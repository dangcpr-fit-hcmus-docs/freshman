#include "Bai3.h"

int main()
{
    loadMenu();
    return 0;
}