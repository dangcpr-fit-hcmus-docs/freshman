#include "Bai1.h"

int main()
{
    loadMenu();
    return 0;
}