#include "Bai2.h"

int main()
{
    loadMenu();
    return 0;
}