#pragma once
#include <iostream>
using namespace std;

float F(float x, unsigned int n);
float LT(float x, unsigned int n);
unsigned long long GT(unsigned int n);
float Fk(float x, unsigned int n);

void CauA(float x, unsigned int n);
void CauB(float x, unsigned int n);
void CauC(float x, unsigned int n);
void CauD(float x, unsigned int n);

void loadMenu();

